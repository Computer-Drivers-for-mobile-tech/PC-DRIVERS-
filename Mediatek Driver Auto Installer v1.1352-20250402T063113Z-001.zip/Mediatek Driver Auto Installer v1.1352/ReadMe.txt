This application will install USB com port driver for MediaTek's device those IDs are listed below:

"VID_0E8D&PID_0003"       (FeaturePhone & Smartphone BootROM - MTK USB Port)

"VID_0E8D&PID_0023&MI_00" (FeaturePhone - MTK USB Modem Port)

"VID_0E8D&PID_0023&MI_02" (FeaturePhone - MTK USB Debug Port)

"VID_0E8D&PID_2000"       (SmartPhone - Preloaer USB Port)

"VID_0E8D&PID_2001"       (SmartPhone - DA USB Port)

"VID_0E8D&PID_2006&MI_02" (SmartPhone - Kernel Gadget USB port, Please customize your kernel VID/PID)
"VID_0E8D&PID_2007"
"VID_0E8D&PID_200a&MI_02" 

